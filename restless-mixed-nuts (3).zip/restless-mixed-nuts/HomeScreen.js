import * as React from 'react';
import {
  Text,
  View,
  StyleSheet,
  Button,
  TouchableHighlight,
  FlatList,
  Alert,
  AsyncStorage,
} from 'react-native';
import Constants from 'expo-constants';

export default class HomeScreen extends React.Component {
  static navigationOptions = {
    title: 'Reminders',
    headerStyle: { backgroundColor: '#6b52ae' },
    headerTitleStyle: { color: '#fff' },
  };
  constructor() {
    super();
    this.state = {
      reminders: [],
    };
    // AsyncStorage.clear();
  }
  
  componentDidMount = async () => {
    try {
      const value = await AsyncStorage.getItem('Reminders');
      alert(JSON.stringify(value));
      if (value !== null) {
        alert(JSON.stringify(value));
        this.setState({ reminders: value });
      }
    } catch (error) {
      alert(error);
    }
  };
  renderSeparator = () => (
    <View
      style={{
        backgroundColor: 'lightgray',
        height: 1,
      }}
    />
  );
  deleteReminder() {
    Alert.alert(
      'Delete Reminder',
      'Are you sure?',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        { text: 'OK', onPress: () => console.log('OK Pressed') },
      ],
      { cancelable: false }
    );
  }
  render() {
    if (this.state.reminders.length) {
      return (
        <View style={styles.container}>
          <FlatList
            data={this.state.reminders}
            showsVerticalScrollIndicator={false}
            ItemSeparatorComponent={this.renderSeparator}
            renderItem={({ item }) => (
              <View style={styles.flatview}>
                <Text style={styles.note}>{item.note}</Text>
                <Text style={styles.timestamp}>{item.timestamp}</Text>
                <TouchableHighlight
                  style={styles.deleteButton}
                  onPress={() => this.deleteReminder()}>
                  <Text style={{ color: 'red' }}>Delete</Text>
                </TouchableHighlight>
              </View>
            )}
            keyExtractor={item => item.id}
          />
          <TouchableHighlight
            onPress={() => this.props.navigation.navigate('AddReminderScreen')}
            style={styles.addButton}>
            <Text style={styles.addSign}>+</Text>
          </TouchableHighlight>
        </View>
      );
    } else {
      return (
        <View style={styles.container}>
          <Text style={styles.noReminder}>No reminders</Text>
          <TouchableHighlight
            onPress={() => this.props.navigation.navigate('AddReminderScreen')}
            style={styles.addButton}>
            <Text style={styles.addSign}>+</Text>
          </TouchableHighlight>
        </View>
      );
    }
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    // paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 0,
  },
  addSign: {
    color: '#fff',
    fontSize: 30,
  },
  addButton: {
    borderWidth: 1,
    borderColor: '#6b52ae',
    alignItems: 'center',
    justifyContent: 'center',
    width: 70,
    position: 'absolute',
    bottom: 10,
    right: 10,
    height: 70,
    backgroundColor: '#6b52ae',
    borderRadius: 100,
  },
  flatview: {
    justifyContent: 'center',
    paddingTop: 10,
    paddingBottom: 10,
    paddingLeft: 15,
    borderRadius: 2,
  },
  note: {
    fontFamily: 'Verdana',
    fontSize: 18,
  },
  timestamp: {
    color: 'gray',
  },
  deleteButton: {
    right: 10,
    position: 'absolute',
  },
  noReminder: {
    textAlign: 'center',
    alignItems: 'center',
    color: 'gray',
    fontSize: 20,
    marginTop: 20,
  },
});

import * as React from 'react';
import Navigator from './Navigator';

export default class App extends React.Component {
  render() {
    return <Navigator />;
  }
}

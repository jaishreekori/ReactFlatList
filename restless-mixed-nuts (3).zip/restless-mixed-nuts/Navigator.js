import { createStackNavigator } from 'react-navigation';
import HomeScreen from './HomeScreen';
import AddReminderScreen from './AddReminderScreen';
const Navigator = createStackNavigator(
  {
    Home: {
      screen: HomeScreen,
    },
    AddReminderScreen: {
      screen: AddReminderScreen,
    },
  },
  {
    initialRouteName: 'Home',
  }
);

export default Navigator;

import * as React from 'react';
import {
  Text,
  View,
  StyleSheet,
  Button,
  TextInput,
  DatePickerAndroid,
  TouchableOpacity,
  TimePickerAndroid,
  TouchableHighlight,
  AsyncStorage,
} from 'react-native';
import Constants from 'expo-constants';

export default class AddReminderScreen extends React.Component {
  static navigationOptions = {
    title: 'Add Reminder',
    headerStyle: { backgroundColor: '#6b52ae' },
    headerTitleStyle: { color: '#fff' },
    headerTintColor: '#fff',
  };
  constructor() {
    super();
    this.setDate = this.setDate.bind(this);
    this.state = {
      note: '',
      chosenDate: new Date(),
      chosenAndroidTime: '00:00',
      androidDate: `${new Date().getUTCDate()}/${new Date().getUTCMonth() +
        1}/${new Date().getUTCFullYear()}`,
      value: 50,
    };
  }
  setDate(newDate) {
    this.setState({ chosenDate: newDate });
  }
  setDateAndroid = async () => {
    try {
      const { action, year, month, day } = await DatePickerAndroid.open({
        date: new Date(),
        minDate: new Date(),
      });
      if (action !== DatePickerAndroid.dismissedAction) {
        this.setState({ androidDate: `${day}/${month + 1}/${year}` });
      }
    } catch ({ code, message }) {
      console.warn('Cannot open date picker', message);
    }
  };

  setTimeAndroid = async () => {
    try {
      const { action, hour, minute } = await TimePickerAndroid.open({
        hour: 14,
        minute: 0,
        is24Hour: false, // Will display '2 PM'
      });
      if (action !== TimePickerAndroid.dismissedAction) {
        // Selected hour (0-23), minute (0-59)
        const m = minute < 10 ? `0${minute}` : minute;
        const h = hour < 10 ? `0${hour}` : hour;
        console.log(`time: ${hour}:${minute}`);
        this.setState({ chosenAndroidTime: `${h}:${m}` });
      }
    } catch ({ code, message }) {
      console.warn('Cannot open time picker', message);
    }
  };

  addReminder = async () => {
    let reminder = {
      note: this.state.note,
      timestamp: this.state.androidDate + '' + this.state.chosenAndroidTime,
    };
    AsyncStorage.getItem('Reminders').then(reminders => {
      const r = reminders ? JSON.parse(reminders) : [];
      r.push(reminder);
      AsyncStorage.setItem('Reminders', JSON.stringify(r));
    });
    alert('Reminder saved successfully.');
    this.props.navigation.navigate('Home')
  };
  render() {
    return (
      <View style={styles.container}>
        <TextInput
          style={styles.input}
          underlineColorAndroid="transparent"
          placeholder="Enter note"
          placeholderTextColor="#9a73ef"
          autoCapitalize="none"
          value={this.state.note}
          onChangeText={note => this.setState({ note })}
        />
        <TouchableOpacity onPress={() => this.setDateAndroid()}>
          <View style={styles.input}>
            <Text>{this.state.androidDate}</Text>
          </View>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => this.setTimeAndroid()}>
          <View style={styles.input}>
            <Text>{this.state.chosenAndroidTime}</Text>
          </View>
        </TouchableOpacity>
        <TouchableHighlight
          style={styles.saveButton}
          onPress={() => this.addReminder()}>
          <Text style={styles.saveButtonText}>Save</Text>
        </TouchableHighlight>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  input: {
    padding: 10,
    marginRight: 10,
    marginLeft: 10,
    height: 40,
    borderColor: '#6b52ae',
    borderWidth: 1,
    borderRadius: 50,
    marginBottom: 10,
  },
  saveButton: {
    marginRight: 10,
    marginLeft: 10,
    backgroundColor: '#6b52ae',
    borderRadius: 50,
    textAlign: 'center',
    padding: 10,
  },
  saveButtonText: {
    color: '#fff',
    textAlign: 'center',
  },
});
